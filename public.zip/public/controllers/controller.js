function AppCtrl($scope, $http){
  console.log("hello world");
  var refresh = function(){
    $http.get('/appointmentList').success(function(response) {
      console.log("I got the requested data");
      $scope.appointmentList = response;
      $scope.appointment = "";
    });
  };

  refresh();

  $scope.addAppointment = function(){
    $http.post('/appointmentlist',$scope.appointment).success(function(response){
        console.log(response);
        refresh();
    });
  };

  $scope.remove = function(id){
    console.log(id);
    $http.delete('/appointmentlist/' + id).success(function(response){
      refresh();
    });
  };
  $scope.edit = function(id){
    console.log(id);
    $http.get('/appointmentlist/' + id).success(function(response){
      $scope.appointment = response;
    });
  };
  $scope.update = function(){
    console.log($scope.appointment._id);
    $http.put('/appointmentlist/' + $scope.appointment._id, $scope.appointment).success(function(response){
      refresh();
    })

  };
}
